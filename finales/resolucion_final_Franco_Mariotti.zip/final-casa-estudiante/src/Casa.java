import java.util.ArrayList;
import java.util.List;
import Componentes.ComponenteCasa;

public class Casa {
    private int ambientes;
    private int metros;
    private List<ComponenteCasa> componentes;

    public Casa(int ambientes,int metros) {
        this.ambientes = ambientes;
        this.metros = metros;
        this.componentes = new ArrayList<ComponenteCasa>();
    }

    public void agregarComponente(ComponenteCasa componenteElectrico) {
        componentes.add(componenteElectrico);
    }

    public int getGastoTotal() {

        int gasto = 0;

        for(ComponenteCasa componente: componentes) {
            gasto += componente.getConsumo(ambientes,metros);
        }

        return gasto;
    }

}

