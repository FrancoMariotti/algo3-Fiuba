package Maderas;

import Maderas.Madera;

public class Pino extends Madera {
    private int coeficienteCalorico;

    public Pino(int peso,int precioPorKilogramo,int coeficienteCalorico) {
        super(peso,precioPorKilogramo);
        this.coeficienteCalorico = coeficienteCalorico;
    }

    @Override
    public int calcularGasto(int metros) {
        return (metros * peso * precioPorKilogramo)/ coeficienteCalorico;
    }
}
