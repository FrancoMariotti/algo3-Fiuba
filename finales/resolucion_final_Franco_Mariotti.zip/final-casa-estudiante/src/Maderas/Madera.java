package Maderas;

public abstract class Madera {
    protected int precioPorKilogramo;
    protected int peso;

    public Madera(int peso,int precioPorKilogramo) {
        this.precioPorKilogramo = precioPorKilogramo;
        this.peso = peso;
    }

    public int getPeso() {
        return this.peso;
    }

    public abstract int calcularGasto(int metros);
}
