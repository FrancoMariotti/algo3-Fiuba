package Maderas;

import Maderas.Madera;

public class Quebracho extends Madera {
    private int pureza;

    public Quebracho(int precioPorKilogramo,int peso,int pureza) {
        super(peso,precioPorKilogramo);
        this.pureza = pureza;
    }

    @Override
    public int calcularGasto(int metros) {
        return pureza * peso * metros *precioPorKilogramo;
    }
}
