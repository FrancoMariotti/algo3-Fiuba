package Componentes;

public class CapacidadMaximaDeMaderaAlcanzadaException extends Exception {
}
