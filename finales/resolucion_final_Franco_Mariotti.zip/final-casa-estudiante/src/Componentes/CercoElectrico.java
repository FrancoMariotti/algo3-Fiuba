package Componentes;

public class CercoElectrico implements ComponenteCasa {
    private int precioKw;

    public CercoElectrico(int precioKw) {
        this.precioKw = precioKw;
    }

    @Override
    public int getConsumo(int ambientes,int metros) {
        return metros * precioKw;
    }
}
