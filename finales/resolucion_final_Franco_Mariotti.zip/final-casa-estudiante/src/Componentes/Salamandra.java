package Componentes;
import Maderas.Madera;

import java.util.ArrayList;
import java.util.List;

public class Salamandra implements ComponenteCasa {
    private static final int CAPACIDAD_MAXIMA = 15;

    private List<Madera> maderas;
    private int capacidad;

    public Salamandra() {
        capacidad = 0;
        maderas = new ArrayList<Madera>();
    }

    public void agregarMadera(Madera madera) throws CapacidadMaximaDeMaderaAlcanzadaException {
        capacidad += madera.getPeso();
        System.out.println(capacidad);

        if(capacidad >= CAPACIDAD_MAXIMA) {
            throw new CapacidadMaximaDeMaderaAlcanzadaException();
        }
        maderas.add(madera);
    }

    @Override
    public int getConsumo(int ambientes, int metros) {
        int gasto = 0;

        for(Madera madera: maderas) {
            gasto += madera.calcularGasto(metros);
        }

        return gasto;
    }
}
