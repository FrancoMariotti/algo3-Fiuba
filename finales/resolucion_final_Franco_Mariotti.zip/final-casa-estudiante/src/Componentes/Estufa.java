package Componentes;

public class Estufa implements ComponenteCasa {
    private int precioKw;
    private int calorias;

    public Estufa(int precioKw,int calorias) {
        this.precioKw = precioKw;
        this.calorias = calorias;
    }

    @Override
    public int getConsumo(int ambientes, int metros) {
        return ambientes * precioKw * calorias;
    }
}
