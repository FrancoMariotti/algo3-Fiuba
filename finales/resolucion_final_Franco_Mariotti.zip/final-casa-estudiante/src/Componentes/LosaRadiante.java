package Componentes;

public class LosaRadiante implements ComponenteCasa {
    private int precioKw;

    public LosaRadiante(int precioKw) {
        this.precioKw = precioKw;
    }

    @Override
    public int getConsumo(int ambientes, int metros) {
        return precioKw * metros * metros;
    }
}
