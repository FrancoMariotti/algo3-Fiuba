package Componentes;

public interface ComponenteCasa {
    int getConsumo(int ambientes,int metros);
}
