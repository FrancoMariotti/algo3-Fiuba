import Componentes.CapacidadMaximaDeMaderaAlcanzadaException;
import Componentes.Salamandra;
import Maderas.Pino;
import org.junit.Test;

public class SalamandraTest {

    @Test(expected = CapacidadMaximaDeMaderaAlcanzadaException.class)
    public void test00NoSePuedeAgregarMasDe15KgDeMaderaASalamandra() throws CapacidadMaximaDeMaderaAlcanzadaException {
        Salamandra salamandra = new Salamandra();
        salamandra.agregarMadera(new Pino(16,2,3));
    }
}
