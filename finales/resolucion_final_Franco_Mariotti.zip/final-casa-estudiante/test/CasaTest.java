import Componentes.*;
import Maderas.Pino;
import Maderas.Quebracho;
import org.junit.Test;

public class CasaTest {
    @Test
    public void test00CasaDeUnAmbientey10MetrosCuadradosSeCreaCorrectamente() {
        Casa casa = new Casa(1,10);

        org.junit.Assert.assertNotNull(casa);
    }

    @Test
    public void test01CasaDeUnAmbienteY10MetrosCuadradosConEstufaDeConsumo10PesosPorKiloWattConsumeEnTotal10000Pesos() {
        //Arrange
        Casa casa =  new Casa(1,10);
        ComponenteCasa estufaDelBanio = new Estufa(10,1000);

        casa.agregarComponente(estufaDelBanio);

        //Act y Assert
        org.junit.Assert.assertEquals(10000, casa.getGastoTotal());
    }

    @Test
    public void test02CasaDeUnAmbienteY10MetrosCuadradosConLosaRadianteDeConsumo10PesosPorKiloWattConsumeEnTotal1000Pesos() {
        //Arrange
        Casa casa =  new Casa(1,10);
        ComponenteCasa losaRadiante = new LosaRadiante(10);

        casa.agregarComponente(losaRadiante);

        //Act y Assert
        org.junit.Assert.assertEquals(1000, casa.getGastoTotal());
    }

    @Test
    public void test03CasaDeUnAmbienteY10MetrosCuadradosConCercoElectricoDeConsumo10PesosPorKiloWattConsumeEnTotal100Pesos() {
        //Arrange
        Casa casa =  new Casa(1,10);
        ComponenteCasa losaRadiante = new CercoElectrico(10);

        casa.agregarComponente(losaRadiante);

        //Act y Assert
        org.junit.Assert.assertEquals(100, casa.getGastoTotal());
    }

    @Test
    public void test04CasaDeUnAmbienteY10MetrosConSalamandraConQuebrachoDe2KgConsumeTotal160Pesos() throws CapacidadMaximaDeMaderaAlcanzadaException {
        //Arrange
        Casa casa =  new Casa(1,10);
        Salamandra salamandra = new Salamandra();
        salamandra.agregarMadera(new Quebracho(4,2,2));

        casa.agregarComponente(salamandra);

        //Act y Assert
        org.junit.Assert.assertEquals(160, casa.getGastoTotal());
    }


    @Test
    public void test05CasaDeUnAmbienteY10MetrosConSalamandraConPinoDe2KgConsumeTotal20Pesos() throws CapacidadMaximaDeMaderaAlcanzadaException {
        //Arrange
        Casa casa =  new Casa(1,10);
        Salamandra salamandra = new Salamandra();
        salamandra.agregarMadera(new Pino(3,2,3));

        casa.agregarComponente(salamandra);

        //Act y Assert
        org.junit.Assert.assertEquals(20, casa.getGastoTotal());
    }

    @Test
    public void test06CasaDeUnAmbienteY10MetrosConSalamandraSinMaderaConsumeTotalCeroPesos() {
        //Arrange
        Casa casa =  new Casa(1,10);
        Salamandra salamandra = new Salamandra();

        casa.agregarComponente(salamandra);

        //Act y Assert
        org.junit.Assert.assertEquals(0, casa.getGastoTotal());
    }

}
